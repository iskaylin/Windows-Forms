﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;



namespace YurtOtomasyon
{
     public class SqlBaglantim

    {
        public SqlConnection baglanti()
        {
            SqlConnection baglan =new SqlConnection((@"Data Source=AYLIN\SQLEXPRESS;Initial Catalog=YurtOtomasyon;Integrated Security=True"));
            baglan.Open();
            return baglan;

        }
    }
}
