﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace YurtOtomasyon
{
    public partial class FrmOgrDuzenle : Form
    {
        public FrmOgrDuzenle()
        {
            InitializeComponent();
        }
        public string id,ad,soyad,TC,telefon,dogum,bolum,mail,odano,veliad,velitel,adres;

        private void Btnsil_Click_1(object sender, EventArgs e)
        {
            SqlCommand komutoda = new SqlCommand("update Odalar set OdaAktif=OdaAktif-1 where OdaNo=@oda", bgl.baglanti());
            komutoda.Parameters.AddWithValue("@oda",Convert.ToInt16(CmbOdaNo.Text));
           komutoda.ExecuteNonQuery();
            bgl.baglanti().Close();
        }

        private void BtnSil_Click(object sender, EventArgs e)
        {
        }

        SqlBaglantim bgl = new SqlBaglantim();
        private void BtnGuncelle_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand komut = new SqlCommand(" update Ogrenci set OgrAd =@p1,OgrSoyad =@p2,OgrTC=@p3,OgrTelefon =@p4,OgrDogum=@p5,OgrBolum=@p6,OgrMail=@p7,OgrOdaNo=@p8,OgrVeliAdSoyad=@p9,OgrVeliTelefon=@p10,OgrVeliAdres=@p11", bgl.baglanti());
            komut.Parameters.AddWithValue("@p1", TxtOgrAd.Text);
            komut.Parameters.AddWithValue("@p2", TxtOgrSoyad.Text);
            komut.Parameters.AddWithValue("@p3", MskTC.Text);
            komut.Parameters.AddWithValue("@p4", MskOgrTelefon.Text);
            komut.Parameters.AddWithValue("@p5", MskDogum.Text);
            komut.Parameters.AddWithValue("@p6", CmbBolum.Text);
            komut.Parameters.AddWithValue("@p7", MskMail.Text);
            komut.Parameters.AddWithValue("@p8", CmbOdaNo.Text);
            komut.Parameters.AddWithValue("@p9", TxtVeliAdSoyad.Text);
            komut.Parameters.AddWithValue("@p10", MskVeliTelefon.Text);
            komut.Parameters.AddWithValue("@p11", RchAdres.Text);
            komut.ExecuteNonQuery();
            bgl.baglanti().Close();
                MessageBox.Show("Güncelleme Başarılı");
               

            }
            catch
            {
                MessageBox.Show("hata");
            }






            








        }

        private void FrmOgrDuzenle_Load(object sender, EventArgs e)
        {
            //label1.Text = id;
            TxtOgrAd.Text = ad;
            TxtOgrSoyad.Text = soyad;
            MskTC.Text = TC;
            MskOgrTelefon.Text = telefon;
            MskDogum.Text = dogum;
            CmbBolum.Text = bolum;
            MskMail.Text = mail;
            CmbOdaNo.Text = odano;
            TxtVeliAdSoyad.Text = veliad;
            MskVeliTelefon.Text = velitel;
            RchAdres.Text = adres;

        }
    }
}
